package com.betyani.dto;

import lombok.Data;

@Data
public class Item {

    private String airline;
    private String flightId;
    private String scheduleDateTime;
    private String estimatedDateTime;
    private String airport;
    private String chkinrange;
    private String gatenumber;
    private String codeshare;
    private String masterflightid;
    private String remark;
    private String airportCode;
    private String terminalid;
    private String typeOfFlight;
    private String fid;
    private String fstandposition;

}
