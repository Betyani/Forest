package com.betyani.service;

import java.util.ArrayList;

import com.betyani.dto.IataDto;
import com.betyani.dto.Item;

public interface AirportService {
	public ArrayList<Item> allItems(String date, String code);
	public ArrayList<String> dateList();
	public ArrayList<IataDto> japanIata();
}
