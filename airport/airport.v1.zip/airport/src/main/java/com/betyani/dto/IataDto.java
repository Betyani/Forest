package com.betyani.dto;

import lombok.Data;

@Data
public class IataDto {
	private String country;
	private String name;
	private String iata;
}
