package com.betyani.service;

import java.net.URI;
import java.net.URISyntaxException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.betyani.dto.AirportDto;
import com.betyani.dto.IataDto;
import com.betyani.dto.Item;
import com.betyani.mapper.IataMapper;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@AllArgsConstructor
@Service
public class AirportServiceImpl implements AirportService {
	
	private IataMapper mapper;	
	
	@Override
	public ArrayList<Item> allItems(String date, String code) {

		ArrayList<Item> allItems = new ArrayList<Item>();
		RestTemplate restTemplate = new RestTemplate();
		Set<String> uniqueKeys = new HashSet<>();

		int pageNo = 1;
		int numOfRows = 10;
		int totalCount = 0;

		do {

			final String API_KEY = "HcUxn51F3zU%2FZw5D9rIwFUZDJsEVZeh8vwVDy18o5h2d8urGqTqmnpLd8XgzHBgaDzw8aGlhBQ9629uFXhnTuA%3D%3D";
			final String API_URL = "http://apis.data.go.kr/B551177/StatusOfPassengerFlightsDeOdp/getPassengerDeparturesDeOdp?type=json";
			String query = String.format("&servicekey=%s&airport_code=%s&pageNo=%d&numOfRows=%d&searchday=%s", API_KEY,
					code, pageNo, numOfRows, date);

			URI uri = null;
			try {
				uri = new URI(API_URL + query);
			} catch (URISyntaxException e) {
				e.printStackTrace();
			}

			AirportDto api = restTemplate.getForObject(uri, AirportDto.class);
			log.info("===항공정보 확인===" + api);

			if (pageNo == 1) {
				totalCount = api.response.body.totalCount;
			}
			
			for(Item i : api.response.body.items) {
				String key = i.getAirline() + "_" + i.getFlightId() + "_" + i.getScheduleDateTime();
				if(!uniqueKeys.contains(key)) {
					allItems.add(i);
					uniqueKeys.add(key);
				}
				
			}
			

			pageNo++;

		} while (allItems.size() < totalCount);

		return allItems;
	}
	
	
	@Override
	public ArrayList<String> dateList() {
		ArrayList<String> dateList = new ArrayList<>();
		LocalDate today = LocalDate.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
		
		for(int i = -3; i <= 6; i++) {
			LocalDate targetDate = today.plusDays(i);
			String date = targetDate.format(formatter);
			dateList.add(date);
		}
		
		return dateList;
	}
	
	
	@Override
	public ArrayList<IataDto> japanIata() {
		return mapper.japanIata();
	}
		
	
}
