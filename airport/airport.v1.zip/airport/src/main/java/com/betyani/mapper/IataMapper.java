package com.betyani.mapper;

import java.util.ArrayList;

import com.betyani.dto.IataDto;

public interface IataMapper {
	public ArrayList<IataDto> japanIata();
}
