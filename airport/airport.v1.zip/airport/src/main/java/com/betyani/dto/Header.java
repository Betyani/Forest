package com.betyani.dto;

import lombok.Data;

//@Data
//public class Header {
//
//    private String resultCode;
//    private String resultMsg;
//
//}

public class Header {

    public String resultCode;
    public String resultMsg;

}
