package com.betyani.dto;

//@Data
//public class AirportDto {
//
//    private Response response;
//
//}

public class AirportDto {

    public Response response;

}
