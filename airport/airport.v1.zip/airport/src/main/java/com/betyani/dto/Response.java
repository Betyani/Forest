package com.betyani.dto;

import lombok.Data;

//@Data
//public class Response {
//
//    private Header header;
//    private Body body;
//
//}

public class Response {

    public Header header;
    public Body body;

}
