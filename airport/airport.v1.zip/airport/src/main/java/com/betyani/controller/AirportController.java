package com.betyani.controller;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.betyani.dto.Item;
import com.betyani.service.AirportService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@RequestMapping("/api/*")
@AllArgsConstructor
@Controller
public class AirportController {

	private AirportService service;
	
	
	@RequestMapping("/site")
	public void mainSite(Model model) {
		log.info("====날짜범위====" + service.dateList());
		log.info("====공항IATA====" + service.japanIata());
		model.addAttribute("dateList", service.dateList());
		model.addAttribute("iataList", service.japanIata());
	}
	
	
	@RequestMapping("/airport")
	public void airport(@RequestParam("date") String date, @RequestParam("code") String code, Model model) {
		ArrayList<Item> items = service.allItems(date, code);

		for (Item i : items) {
			String info = String.format("항공사: %s, 편명: %s, 체크인카운터: %s, 탑승구: %s, 출발예정시간: %s, 터미널: %s", i.getAirline(),
					i.getFlightId(), i.getChkinrange(), i.getGatenumber(), i.getScheduleDateTime(), i.getTerminalid());
			log.info(info);
		}
		
		model.addAttribute("info", items);

	}

}
