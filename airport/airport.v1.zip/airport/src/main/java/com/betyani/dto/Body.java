package com.betyani.dto;

import java.util.List;

import lombok.Data;

//@Data
//public class Body {
//
//    private Integer numOfRows;
//    private Integer pageNo;
//    private Integer totalCount;
//    private List<Item> items;
//
//}

public class Body {

    public Integer numOfRows;
    public Integer pageNo;
    public Integer totalCount;
    public List<Item> items;

}