function br() {
    document.write("<br>");
}

function dw(x) {
    document.write(x);
}

function hr() {
    document.write("<hr>");
}
